/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/@next+font@13.1.6";
exports.ids = ["vendor-chunks/@next+font@13.1.6"];
exports.modules = {

/***/ "./node_modules/.pnpm/@next+font@13.1.6/node_modules/@next/font/google/target.css?{\"path\":\"src\\\\pages\\\\_app.tsx\",\"import\":\"Lexend\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"lexend\"}":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@next+font@13.1.6/node_modules/@next/font/google/target.css?{"path":"src\\pages\\_app.tsx","import":"Lexend","arguments":[{"subsets":["latin"]}],"variableName":"lexend"} ***!
  \******************************************************************************************************************************************************************************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"style\": {\"fontFamily\":\"'__Lexend_eab306', '__Lexend_Fallback_eab306'\",\"fontStyle\":\"normal\"},\n\t\"className\": \"__className_eab306\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvLnBucG0vQG5leHQrZm9udEAxMy4xLjYvbm9kZV9tb2R1bGVzL0BuZXh0L2ZvbnQvZ29vZ2xlL3RhcmdldC5jc3M/e1wicGF0aFwiOlwic3JjXFxcXHBhZ2VzXFxcXF9hcHAudHN4XCIsXCJpbXBvcnRcIjpcIkxleGVuZFwiLFwiYXJndW1lbnRzXCI6W3tcInN1YnNldHNcIjpbXCJsYXRpblwiXX1dLFwidmFyaWFibGVOYW1lXCI6XCJsZXhlbmRcIn0iLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBLFdBQVcsa0ZBQWtGO0FBQzdGO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LXZlcnNpb24vLi9ub2RlX21vZHVsZXMvLnBucG0vQG5leHQrZm9udEAxMy4xLjYvbm9kZV9tb2R1bGVzL0BuZXh0L2ZvbnQvZ29vZ2xlL3RhcmdldC5jc3M/ZGEwZiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJzdHlsZVwiOiB7XCJmb250RmFtaWx5XCI6XCInX19MZXhlbmRfZWFiMzA2JywgJ19fTGV4ZW5kX0ZhbGxiYWNrX2VhYjMwNidcIixcImZvbnRTdHlsZVwiOlwibm9ybWFsXCJ9LFxuXHRcImNsYXNzTmFtZVwiOiBcIl9fY2xhc3NOYW1lX2VhYjMwNlwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/.pnpm/@next+font@13.1.6/node_modules/@next/font/google/target.css?{\"path\":\"src\\\\pages\\\\_app.tsx\",\"import\":\"Lexend\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"lexend\"}\n");

/***/ })

};
;